
public class ClassB extends ClassA {

	protected int a;
	
	private int b;

	public ClassB() {
		a = 10;
		b = 20;
		x = 30;
		//y = 40; // private - not inherited
		z = 50;
	}

}
