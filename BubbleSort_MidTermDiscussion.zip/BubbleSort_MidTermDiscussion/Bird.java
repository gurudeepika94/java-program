
public class Bird implements Silly {
   
	public static void main(String args[]) {
		
		System.out.println("zero");
		
		Silly s = new SillyBird(1);//we create a silly bird and assign to type silly, silly bird is implement from bird and bird is implement from silly.
		
		Silly s2 = new Loony();//we create loony and assign it to type silly
		
		s.poit(s2);
		
		s2.poit(s);
		
		System.out.println("zymurgy");
   }
	
   public Bird() {
	   this(0);
	   System.out.println("zircon");
   }
   
   public Bird(int i) {
	   System.out.println("zanzibar");
   }
   
   public void narf() {
     System.out.println("zort");
   } 
   
   public void poit(Silly s) {
      s.narf();
   }
}
