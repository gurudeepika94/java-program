
class Loony extends SillyBird {
	
	// Default Constructor - COnstructor having no arguments.
	public Loony() {
		// compiler will call default constructor of SillyBird
      System.out.println("stupendous");
    }
	
	public void narf() {
		System.out.println("snark");
	}
}
