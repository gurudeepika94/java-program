import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class GridLayoutFrame extends JFrame implements ActionListener {

	public GridLayoutFrame() {

		Container container = getContentPane();
		
		// First two parameters row, column and last two parameters horizontalGap, verticalGap.
		container.setLayout(new GridLayout(2,2, 10, 5));
		
		JButton button1 = new JButton("Click Me 1");
		container.add(button1);
		
		JButton button2 = new JButton("Click Me 2");
		container.add(button2);
		
		JButton button3 = new JButton("Click Me 3");
		container.add(button3);
		
		JButton button4 = new JButton("Click Me 4");
		container.add(button4);
		
		setSize(500,500);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		e.
		
	}

}
