
public class BubbleSortNumbers {
	
	public static void main(String[] args) {
		
		int[] numbers = {100,50,1,0,90};

		BubbleSort(numbers);
		
	}

	public static void BubbleSort(int[] numbers) {
		
		int temp;
		
		printArray(numbers);
		
		for (int i=0; i< numbers.length-1; i++) {
			 
			System.out.println("Iteration: " + (i+1));
			
			// Repeat logic 
			for(int j=0; j< numbers.length-1 ; j++) {

				int num1 = numbers[j];
				int num2 = numbers[j+1];

				// When first number is greater than next number in list then do swap/exchange.
				if (num1 > num2) {
					temp = numbers[j];
					numbers[j] = numbers[j+1];
					numbers[j+1] = temp;
				}

				// For debugging purpose print array.
				printArray(numbers);
			}

		}
		
	}
	
	public static void printArray(int[] list) {
		
		System.out.println("----------------------------");
		for(int i=0; i<list.length; i++) {
			System.out.print(list[i]+ " | ");
		}
		System.out.println("");
		System.out.println("----------------------------");
	}
}
