
public class Child extends Parent {

	private int b;
	
	public Child(int b) {
		
		// Following call is known as default constructor call for super class
		//super();
		this.b = b;
	}

}
