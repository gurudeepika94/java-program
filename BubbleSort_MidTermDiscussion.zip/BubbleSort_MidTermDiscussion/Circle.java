
// Concrete representation of abstract class shape
public class Circle extends Shape {

	private double radius;
	
	public Circle(double radius) {
		this.radius = radius;
	}

	@Override
	double area() {
		return 2 * Math.PI * radius * radius;
	}	
	
	// All abstract methods of abstract class has to be implemented by it's immediate subclass.
}
