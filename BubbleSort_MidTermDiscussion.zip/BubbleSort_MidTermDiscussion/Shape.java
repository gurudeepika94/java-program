
// shape is abstract class. you can't instantiate.
public abstract class Shape {

	abstract double area();
}
