
public class DoubleCircle extends Circle {

	public DoubleCircle(double radius) {
		super(radius);
	}

	public double area() {
		return 0;
	}
}
