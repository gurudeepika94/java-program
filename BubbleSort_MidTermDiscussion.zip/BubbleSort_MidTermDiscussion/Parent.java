
public class Parent {

	private int a;
	
	// Default Constructor
	public Parent() {
		this.a = 0;
	}
	
	// Parameterized Constructor.
	public Parent(int a) {
		this.a = a;
	}

}
