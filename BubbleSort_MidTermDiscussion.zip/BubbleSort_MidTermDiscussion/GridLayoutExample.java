import javax.swing.JFrame;

public class GridLayoutExample {

	public static void main(String[] args) {
		GridLayoutFrame app = new GridLayoutFrame();
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
