
public class AClassExample {


	public static void main(String[] args) {
		
		BClass o = new BClass(1,2,3);
		
	    System.out.println(o);
	}

}
