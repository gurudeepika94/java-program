import javax.swing.JFrame;

public class BorderLayoutExample {

	// JPanel - Default Layout is Flow Layout (Direction: Left to Right)
	// JFrame - Default Layout is Border Layout
	
	public static void main(String[] args) {
		BorderLayoutFrame app = new BorderLayoutFrame();
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
