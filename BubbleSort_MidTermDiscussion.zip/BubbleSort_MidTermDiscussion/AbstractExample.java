
public class AbstractExample {

	public static void main(String[] args) {
		
		// ABstract class can't be instantiated
		//Shape s = new Shape();
		
		// Abstract class can only be public. (no private, no protected)
		// Abstract class will have abstract method.
		
		// Abstract class can be extended. Here circle class is extended from shape class.
		Circle c = new Circle(10.0);
		double circle_Area = c.area();
		System.out.println(circle_Area);
		
	}

}
