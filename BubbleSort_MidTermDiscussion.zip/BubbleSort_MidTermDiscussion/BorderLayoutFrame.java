import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class BorderLayoutFrame extends JFrame {

	public BorderLayoutFrame() {
		
		Container container = getContentPane();
		container.setLayout(new BorderLayout());
		
		JButton button1 = new JButton("Top Button");
		container.add(button1, BorderLayout.NORTH);
		
		JButton button2 = new JButton("Bottom Button");
		container.add(button2, BorderLayout.SOUTH);
		
		JButton button3 = new JButton("Left Button");
		container.add(button3, BorderLayout.WEST);
		
		JButton button4 = new JButton("Right Button");
		container.add(button4, BorderLayout.EAST);
		
		JButton button5 = new JButton("Center Button");
		container.add(button5, BorderLayout.CENTER);
		
		setSize(500,500);
		setVisible(true);
	}

}
