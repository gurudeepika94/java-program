import java.util.Scanner;

public class BubbleSort {
	
	public static void main(String[] args) {
		
		String[] list;
		list=new String[10];
		String temp;
		
		Scanner input=new Scanner(System.in);

		for(int i=0;i<10;i++){
			System.out.println("Enter Name :");
			list[i]=input.next();
		}
		
		for(int x=1; x<10; x++) {
			
			for(int y=0; y<10-x; y++) {
				
				if(list[y].compareTo(list[y+1])>0) {
					temp=list[y];
					list[y]=list[y+1];
					list[y+1]=temp;
				}
			}
		}
		
		for(int i=0;i<10;i++) {
			System.out.println("Sorted Names are " + list[i]);
		}
	}

}