
class SillyBird extends Bird {
	
	public SillyBird() {
		System.out.println("duchess");
	}
	
	public SillyBird(int i) {
		super(i);
	}
	
	public void narf() {
		System.out.println("drum");
		super.narf();
	}
}
