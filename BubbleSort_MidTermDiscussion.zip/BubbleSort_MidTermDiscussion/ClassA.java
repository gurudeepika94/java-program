
public class ClassA {

	// Guest Room - Main Hall Area
	public int x;
	
	// Private Locker Room
	private int y;
	
	// Family Members who can also come to your private room
	protected int z;

	public ClassA() {
	
	}

}
