
public class BClass extends AClass {

	private int z;
	
	public BClass(int a, int b, int c) {
		super(a, b);
		z = c;
	}

	public String toString() {
		return super.toString() + "\n" + this.z;
	}
}
