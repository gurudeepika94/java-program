
public class ClassC extends ClassA {

	private int q;

	public ClassC() {
		x = 10;
		//y = 20; // private
		z = 30;
		q = 40;
	}

}

/*
ClassA
private int y;

public int x;
protected int z;

Class B -> Class A
inherited
public int x;
protected int z;

New members class B
protected int a;
private int b; // no inheritance

Class C -> Class B
inherited
a
z
x

New Member
private int q;


*/