
public class BubbleSortStrings {
	
	public static void main(String[] args) {
		
		String[] names = {"Sharon","Deepika","Ahmed","Ruchish","Ruchi"};

		BubbleSortStrings(names);
		
	}

	public static void BubbleSortStrings(String[] names) {
		
		String temp;
		
		printArray(names);
		
		for (int i=0; i< names.length-1; i++) {
			 
			System.out.println("Iteration: " + (i+1));
			
			// Repeat logic 
			for(int j=0; j< names.length-1 ; j++) {

				String name1 = names[j];
				String name2 = names[j+1];

				// When first name is greater than next name in list then do swap/exchange.  (Ascending order - alphabetical order)
				if (name1.compareTo(name2) > 0) {
					temp = names[j];
					names[j] = names[j+1];
					names[j+1] = temp;
				}

				// For debugging purpose print array.
				printArray(names);
			}

		}
		
	}
	
	public static void printArray(String[] list) {
		
		System.out.println("----------------------------");
		for(int i=0; i<list.length; i++) {
			System.out.print(list[i]+ " | ");
		}
		System.out.println("");
		System.out.println("----------------------------");
	}
}
