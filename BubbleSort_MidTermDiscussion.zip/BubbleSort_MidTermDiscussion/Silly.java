
public interface Silly {

	// In interface you declare method no implementation
	// i.e what we have to do rather how we are going to do.
	// implementing class will provide definition on how method is going to work.
	public void narf();
	
	public void poit(Silly s);

}
