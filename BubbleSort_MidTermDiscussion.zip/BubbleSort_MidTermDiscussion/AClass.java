
public class AClass {
 
	protected int x;
	
	protected int y;
  
	public AClass(int a, int b){
		//a -> 1
		//b -> 2
		x = a; // 1
		y = b; // 3
	}
	
	//++x -> Increment and use (pre increment)
	//x++ -> Use and then increment. (post increment)
	
	public String toString( ){
		return "x=" + (++x) + "\ny=" + (y++) ;
		//x=2
		//y=2
	}
	
}