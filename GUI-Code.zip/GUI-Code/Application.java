import javax.swing.JFrame;

public class Application {
	
	public static void main(String[] args) {
		//LabelTest app = new LabelTest();
		//TextFieldTest app = new TextFieldTest();
		//ButtonTest app = new ButtonTest();
		//CheckBoxTest app = new CheckBoxTest();
		//RadioButtonTest app = new RadioButtonTest();
		//ComboxBoxTest app = new ComboxBoxTest();
		ListTest app = new ListTest();
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
